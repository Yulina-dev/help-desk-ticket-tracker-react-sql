import { env } from 'cloudflare:workers';
export function ticketDb() {
  if (!env.DB) throw new Error('Database unavailable');
  return env.DB;
}
